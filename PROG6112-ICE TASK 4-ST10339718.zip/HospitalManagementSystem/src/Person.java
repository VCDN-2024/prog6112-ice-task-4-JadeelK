import javax.swing.JOptionPane;

public class Person {
    protected String firstName;
    protected String lastName;
    protected String address;
    protected String zipCode;
    protected String phoneNumber;

    public void setData() {
        firstName = JOptionPane.showInputDialog("Enter first name:");
        lastName = JOptionPane.showInputDialog("Enter last name:");
        address = JOptionPane.showInputDialog("Enter address:");
        zipCode = JOptionPane.showInputDialog("Enter zip code:");
        phoneNumber = JOptionPane.showInputDialog("Enter phone number:");
    }

    public void display() {
        System.out.println("Name: " + firstName + " " + lastName +
                ", Address: " + address + ", Zip: " + zipCode + 
                ", Phone: " + phoneNumber);
    }
}
