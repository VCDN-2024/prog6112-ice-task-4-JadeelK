
import javax.swing.JOptionPane;

public class Doctor extends HospitalStaff {
    private boolean isSpecialist;

    @Override
    public void setData() {
        super.setData();
        int specialistResponse = JOptionPane.showConfirmDialog(null, 
                "Is this doctor a specialist?", "Specialist", JOptionPane.YES_NO_OPTION);
        isSpecialist = (specialistResponse == JOptionPane.YES_OPTION);
    }

    @Override
    public void display() {
        super.display();
        System.out.println(", Specialist: " + (isSpecialist ? "Yes" : "No"));
    }
}
