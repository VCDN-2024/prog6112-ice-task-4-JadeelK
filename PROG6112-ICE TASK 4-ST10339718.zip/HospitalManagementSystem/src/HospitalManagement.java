import javax.swing.JOptionPane;

public class HospitalManagement {
    public static void main(String[] args) {
        HospitalStaff[] staffArray = new HospitalStaff[4];
        Doctor[] doctorArray = new Doctor[3];
        Patient[] patientArray = new Patient[7];

        int staffCount = 0, doctorCount = 0, patientCount = 0;
        String choice;

        do {
            choice = JOptionPane.showInputDialog("Enter H for Hospital Staff, D for Doctor, P for Patient, Q to Quit:");
            switch (choice.toUpperCase()) {
                case "H":
                    if (staffCount < 4) {
                        staffArray[staffCount] = new HospitalStaff();
                        staffArray[staffCount].setData();
                        staffCount++;
                    } else {
                        JOptionPane.showMessageDialog(null, "Max Hospital Staff reached.");
                    }
                    break;
                case "D":
                    if (doctorCount < 3) {
                        doctorArray[doctorCount] = new Doctor();
                        doctorArray[doctorCount].setData();
                        doctorCount++;
                    } else {
                        JOptionPane.showMessageDialog(null, "Max Doctors reached.");
                    }
                    break;
                case "P":
                    if (patientCount < 7) {
                        patientArray[patientCount] = new Patient();
                        patientArray[patientCount].setData();
                        patientCount++;
                    } else {
                        JOptionPane.showMessageDialog(null, "Max Patients reached.");
                    }
                    break;
                case "Q":
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid input.");
            }
        } while (!choice.equalsIgnoreCase("Q"));

        System.out.println("Hospital Staff:");
        if (staffCount == 0) {
            System.out.println("No hospital staff entered.");
        } else {
            for (int i = 0; i < staffCount; i++) {
                staffArray[i].display();
            }
        }

        System.out.println("\nDoctors:");
        if (doctorCount == 0) {
            System.out.println("No doctors entered.");
        } else {
            for (int i = 0; i < doctorCount; i++) {
                doctorArray[i].display();
            }
        }

        System.out.println("\nPatients:");
        if (patientCount == 0) {
            System.out.println("No patients entered.");
        } else {
            for (int i = 0; i < patientCount; i++) {
                patientArray[i].display();
            }
        }
    }
}

