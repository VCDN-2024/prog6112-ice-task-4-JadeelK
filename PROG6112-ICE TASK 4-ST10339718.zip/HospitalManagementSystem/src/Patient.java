
import javax.swing.JOptionPane;

public class Patient extends Person {
    private String medicalRecordNumber;
    private String ailments;

    @Override
    public void setData() {
        super.setData();
        medicalRecordNumber = JOptionPane.showInputDialog("Enter medical record number:");
        ailments = JOptionPane.showInputDialog("Enter current ailments:");
    }

    @Override
    public void display() {
        super.display();
        System.out.println(", Medical Record: " + medicalRecordNumber +
                ", Ailments: " + ailments);
    }
}

