
import javax.swing.JOptionPane;

public class HospitalStaff extends Person {
    protected String staffID;
    protected double salary;
    protected String department;

    @Override
    public void setData() {
        super.setData();
        staffID = JOptionPane.showInputDialog("Enter staff ID:");
        salary = Double.parseDouble(JOptionPane.showInputDialog("Enter annual salary:"));
        department = JOptionPane.showInputDialog("Enter department name:");
    }

    @Override
    public void display() {
        super.display();
        System.out.println(", Staff ID: " + staffID + 
                ", Salary: " + salary + ", Department: " + department);
    }
}

